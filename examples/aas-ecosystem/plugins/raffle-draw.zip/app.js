/*
 * Gewinnspiel-Plugin für die AAS Suite.
 *
 * Liest die Anmeldungen aus der Infrastruktur "Raffle" über den AAS-Proxy der Suite. Der Proxy
 * prüft Login und Infrastruktur-Rechte, das Plugin braucht deshalb kein eigenes Backend (Plugin-
 * Backends sind ohne Login öffentlich erreichbar). Jede Anmeldung ist ein Submodel "Registration"
 * (raffle/app.py). Gewinner und Abwesende werden dort als zusätzliche Elemente vermerkt:
 *   WonAt (xs:dateTime), Prize (Name des Preises), PrizeRef (Verweis auf die Preis-AAS),
 *   AbsentAt (xs:dateTime)
 *
 * Jeder Preis ist eine eigene AAS mit Submodel "Prize" (Rank, Name, Description), angelegt von
 * raffle/app.py. Bei der Vergabe bekommt sie Winner (Verweis auf die AAS der Person) und AwardedAt.
 *
 * Zwei Ansichten: Verwaltung (im iframe der Suite) und Großanzeige (?view=stage, eigener Tab, weil
 * das iframe der Suite kein Vollbild erlaubt). Beide Tabs halten sich über BroadcastChannel aktuell.
 *
 * Sprachen: Deutsch und Englisch, Umschalter in beiden Ansichten. Reihenfolge: ?lang=, zuletzt
 * gewählte Sprache (localStorage), Browsersprache.
 */
'use strict';

const params = new URLSearchParams(location.search);
const INFRA_NAME = params.get('infra') || 'Raffle';
const SEMANTIC_ID = 'urn:aas-demo:raffle:submodel:registration:1:0';
const PRIZE_SEMANTIC_ID = 'urn:aas-demo:raffle:submodel:prize:1:0';
const API = '/designer-api';
const channel = 'BroadcastChannel' in window ? new BroadcastChannel('raffle-draw') : null;

const state = {
  infraId: null,
  people: [],        // { smId, aasId, first, last, company, email, registeredAt, wonAt, prize, prizeAasId, absentAt }
  prizes: [],        // { smId, aasId, rank, name, description, winnerAasId, awardedAt }
  candidate: null,   // gezogen, aber noch nicht bestätigt
  busy: false,
};

const $ = (id) => document.getElementById(id);

// ---------------------------------------------------------------------------------------------
// Sprache
// ---------------------------------------------------------------------------------------------

const TEXTS = {
  de: {
    title: 'Gewinnspiel', stageDocTitle: 'Gewinnspiel – Großanzeige', loading: 'Lade …',
    reload: 'Neu laden', csv: 'CSV exportieren', openStage: 'Großanzeige öffnen',
    nTotal: 'Teilnehmer', nOpen: 'im Lostopf', nWon: 'Gewinner', nAbsent: 'nicht anwesend',
    prizeLabel: 'Preis für diese Ziehung', draw: 'Gewinner ziehen', drawn: 'Gezogen:',
    confirm: 'Als Gewinner eintragen', absent: 'Nicht anwesend, neu ziehen', discard: 'Verwerfen',
    prizes: 'Preise', prizesHint: 'Jeder Preis ist eine eigene AAS in der Infrastruktur. Namen hier ändern und mit Enter speichern.',
    noPrizes: 'Keine Preis-AAS gefunden. Die Raffle-App legt sie beim Start an (RAFFLE_PRIZE_COUNT).',
    list: 'Teilnehmerliste', search: 'Suchen …', searchAria: 'Teilnehmer suchen',
    reveal: 'Vollständige Daten anzeigen', mask: 'Daten wieder kürzen',
    hintMasked: 'Namen und E-Mail-Adressen sind gekürzt.',
    hintRevealed: 'Vollständige Daten sichtbar. Sie werden nach 2 Minuten automatisch wieder gekürzt.',
    thName: 'Name', thCompany: 'Firma', thEmail: 'E-Mail', thRegistered: 'Angemeldet', thStatus: 'Status',
    empty: 'Noch keine Anmeldungen.',
    open: 'im Lostopf', won: 'Gewinner', absentStatus: 'nicht anwesend',
    source: 'Infrastruktur „{name}“ (ID {id})', prize: 'Preis', prizeN: 'Preis {n}',
    noPrize: 'Ohne Preis', noPrizeAll: 'Ohne Preis (alle Preise vergeben)', prizeNameAria: 'Name von Preis {n}',
    awardedTo: 'vergeben an {name}', unknown: 'unbekannt', prizeOpen: 'offen',
    resetTitle: 'Zurück in den Lostopf', reset: 'Zurücksetzen',
    csvCols: ['Vorname', 'Nachname', 'Firma', 'E-Mail', 'Angemeldet', 'Status', 'Gewonnen', 'Preis', 'Nicht anwesend'],
    csvFile: 'gewinnspiel',
    errLogin: 'Nicht angemeldet. Bitte in der AAS Suite anmelden und die Seite neu laden.',
    errForbidden: 'Keine Berechtigung für die Infrastruktur „{name}“.',
    errRequest: 'Anfrage fehlgeschlagen ({status}): {what}',
    errInfra: 'Infrastruktur „{name}“ nicht gefunden oder keine Berechtigung.',
    errNoCandidate: 'Es ist niemand gezogen.', errPrizeGone: 'Den gewählten Preis gibt es nicht mehr. Bitte neu laden.',
    errPrizeTaken: '„{name}“ ist schon vergeben. Bitte einen anderen Preis wählen.', errPotEmpty: 'Der Lostopf ist leer.',
    inPot: '{n} im Lostopf', stageDraw: 'Ziehen', stageConfirm: 'Gewinner', stageAbsent: 'Nicht da', stageFull: 'Vollbild',
    keySpace: 'Leertaste', stagePrompt: 'Anwesend? Enter = Gewinner, N = neu ziehen',
    congrats: 'Herzlichen Glückwunsch!', redraw: 'Nicht anwesend. Neue Ziehung …',
  },
  en: {
    title: 'Prize draw', stageDocTitle: 'Prize draw – big screen', loading: 'Loading …',
    reload: 'Reload', csv: 'Export CSV', openStage: 'Open big screen',
    nTotal: 'Participants', nOpen: 'in the draw', nWon: 'Winners', nAbsent: 'not present',
    prizeLabel: 'Prize for this draw', draw: 'Draw a winner', drawn: 'Drawn:',
    confirm: 'Confirm as winner', absent: 'Not present, draw again', discard: 'Discard',
    prizes: 'Prizes', prizesHint: 'Each prize is its own AAS in the infrastructure. Change names here and press Enter to save.',
    noPrizes: 'No prize AAS found. The raffle app creates them at startup (RAFFLE_PRIZE_COUNT).',
    list: 'Participant list', search: 'Search …', searchAria: 'Search participants',
    reveal: 'Show full details', mask: 'Shorten details again',
    hintMasked: 'Names and email addresses are shortened.',
    hintRevealed: 'Full details are visible. They are shortened again automatically after 2 minutes.',
    thName: 'Name', thCompany: 'Company', thEmail: 'Email', thRegistered: 'Registered', thStatus: 'Status',
    empty: 'No registrations yet.',
    open: 'in the draw', won: 'winner', absentStatus: 'not present',
    source: 'Infrastructure "{name}" (ID {id})', prize: 'Prize', prizeN: 'Prize {n}',
    noPrize: 'No prize', noPrizeAll: 'No prize (all prizes awarded)', prizeNameAria: 'Name of prize {n}',
    awardedTo: 'awarded to {name}', unknown: 'unknown', prizeOpen: 'open',
    resetTitle: 'Put back into the draw', reset: 'Reset',
    csvCols: ['First name', 'Last name', 'Company', 'Email', 'Registered', 'Status', 'Won', 'Prize', 'Not present'],
    csvFile: 'prize-draw',
    errLogin: 'Not signed in. Please sign in to the AAS Suite and reload the page.',
    errForbidden: 'No permission for the infrastructure "{name}".',
    errRequest: 'Request failed ({status}): {what}',
    errInfra: 'Infrastructure "{name}" not found or no permission.',
    errNoCandidate: 'Nobody has been drawn.', errPrizeGone: 'The selected prize no longer exists. Please reload.',
    errPrizeTaken: '"{name}" has already been awarded. Please choose another prize.', errPotEmpty: 'There is nobody left in the draw.',
    inPot: '{n} in the draw', stageDraw: 'Draw', stageConfirm: 'Winner', stageAbsent: 'Not here', stageFull: 'Full screen',
    keySpace: 'Space', stagePrompt: 'Present? Enter = winner, N = draw again',
    congrats: 'Congratulations!', redraw: 'Not present. Drawing again …',
  },
};
const LANGS = Object.keys(TEXTS);
const LANG_KEY = 'raffle-draw-lang';

function storedLang() {
  try { return localStorage.getItem(LANG_KEY); } catch { return null; }
}

function initialLang() {
  const wanted = [params.get('lang'), storedLang(), ...(navigator.languages || [navigator.language])];
  for (const w of wanted) {
    const code = String(w || '').slice(0, 2).toLowerCase();
    if (LANGS.includes(code)) return code;
  }
  return 'en';
}

let lang = initialLang();

function t(key, vars) {
  const text = TEXTS[lang][key] ?? TEXTS.de[key] ?? key;
  return vars ? text.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m)) : text;
}

// Standardnamen der Preis-AAS ("Preis 3") in der gewählten Sprache zeigen, eigene Namen unverändert
function prizeName(name, rank) {
  const m = /^(?:Preis|Prize) (\d+)$/.exec(name || '');
  if (m) return t('prizeN', { n: m[1] });
  return name || t('prizeN', { n: rank });
}

function applyLang() {
  document.documentElement.lang = lang;
  document.title = isStage ? t('stageDocTitle') : t('title');
  document.querySelectorAll('[data-i18n]').forEach((n) => { n.textContent = t(n.dataset.i18n); });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((n) => { n.placeholder = t(n.dataset.i18nPlaceholder); });
  document.querySelectorAll('[data-i18n-aria]').forEach((n) => { n.setAttribute('aria-label', t(n.dataset.i18nAria)); });
  document.querySelectorAll('[data-lang]').forEach((b) => { b.setAttribute('aria-pressed', String(b.dataset.lang === lang)); });
  if (!isStage) updateRevealTexts();
  render();
}

function setLang(code, remember = true) {
  if (!LANGS.includes(code)) return;
  lang = code;
  if (remember) { try { localStorage.setItem(LANG_KEY, code); } catch { /* egal */ } }
  applyLang();
}

// ---------------------------------------------------------------------------------------------
// API
// ---------------------------------------------------------------------------------------------

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function b64url(text) {
  const bytes = new TextEncoder().encode(text);
  let bin = '';
  bytes.forEach((b) => { bin += String.fromCharCode(b); });
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function cookie(name) {
  const hit = document.cookie.split(';').map((c) => c.trim()).find((c) => c.startsWith(name + '='));
  return hit ? decodeURIComponent(hit.slice(name.length + 1)) : null;
}

async function csrfToken() {
  let token = cookie('vws-csrf-request');
  if (!token) {
    await fetch('/bff/csrf', { credentials: 'same-origin' });
    token = cookie('vws-csrf-request');
  }
  return token;
}

async function api(path, { method = 'GET', body } = {}) {
  const headers = { Accept: 'application/json' };
  const orga = sessionStorage.getItem('CURRENT_ORGA_ID');
  if (orga) headers['X-Organisation-ID'] = orga;
  if (state.infraId != null) headers['X-Infrastructure-ID'] = String(state.infraId);
  if (method !== 'GET') {
    headers['X-CSRF-TOKEN'] = await csrfToken();
    if (body !== undefined) headers['Content-Type'] = 'application/json';
  }
  const res = await fetch(API + path, {
    method, headers, credentials: 'same-origin',
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) {
    if (res.status === 401) throw new ApiError(401, t('errLogin'));
    if (res.status === 403) throw new ApiError(403, t('errForbidden', { name: INFRA_NAME }));
    throw new ApiError(res.status, t('errRequest', { status: res.status, what: method + ' ' + path.split('?')[0] }));
  }
  if (res.status === 204) return null;
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

const smRepo = (path) => '/aas-proxy/' + state.infraId + '/sm-repo' + path;
const elementPath = (smId, idShort) => smRepo('/submodels/' + b64url(smId) + '/submodel-elements/' + idShort);

async function findInfrastructure() {
  const list = await api('/aas-api/aasinfrastructure/getavailableinfrastructures');
  const infra = (list || []).find((i) => i.name === INFRA_NAME);
  if (!infra) throw new ApiError(404, t('errInfra', { name: INFRA_NAME }));
  state.infraId = infra.id;
}

// Werte der Elemente nach idShort. ReferenceElements liefern die ID, auf die sie zeigen.
function values(sm) {
  const v = {};
  (sm.submodelElements || []).forEach((e) => {
    v[e.idShort] = e.modelType === 'ReferenceElement' ? ((e.value && e.value.keys && e.value.keys[0]) || {}).value || '' : e.value ?? '';
  });
  return v;
}

function toPerson(sm) {
  const v = values(sm);
  return {
    smId: sm.id,
    // raffle/app.py leitet beide IDs aus demselben Schlüssel ab
    aasId: sm.id.replace(':registration:', ':participant:'),
    first: v.FirstName || '', last: v.LastName || '', company: v.Company || '', email: v.Email || '',
    registeredAt: v.RegisteredAt || '', wonAt: v.WonAt || '', prize: v.Prize || '', prizeAasId: v.PrizeRef || '',
    absentAt: v.AbsentAt || '',
  };
}

function toPrize(sm) {
  const v = values(sm);
  return {
    smId: sm.id,
    aasId: sm.id.replace(':prize-info:', ':prize:'),
    rank: parseInt(v.Rank, 10) || 0, name: v.Name || '', description: v.Description || '',
    winnerAasId: v.Winner || '', awardedAt: v.AwardedAt || '',
  };
}

async function loadSubmodels(semanticId) {
  const all = [];
  let cursor = '';
  do {
    const q = '?semanticId=' + b64url(semanticId) + '&limit=500' + (cursor ? '&cursor=' + encodeURIComponent(cursor) : '');
    const page = await api(smRepo('/submodels' + q));
    all.push(...(page.result || []));
    cursor = page.paging_metadata && page.paging_metadata.cursor;
  } while (cursor);
  return all;
}

async function loadAll() {
  if (state.infraId == null) await findInfrastructure();
  const [people, prizes] = await Promise.all([loadSubmodels(SEMANTIC_ID), loadSubmodels(PRIZE_SEMANTIC_ID)]);
  state.people = people.map(toPerson).sort((a, b) => a.registeredAt.localeCompare(b.registeredAt));
  state.prizes = prizes.map(toPrize).sort((a, b) => a.rank - b.rank);
}

async function setElement(smId, element) {
  try {
    await api(smRepo('/submodels/' + b64url(smId) + '/submodel-elements'), { method: 'POST', body: element });
  } catch (err) {
    if (err.status !== 409) throw err;
    await api(elementPath(smId, element.idShort), { method: 'PUT', body: element });
  }
}

const setProperty = (smId, idShort, valueType, value) =>
  setElement(smId, { modelType: 'Property', idShort, valueType, value });

const setShellReference = (smId, idShort, aasId) => setElement(smId, {
  modelType: 'ReferenceElement', idShort,
  value: { type: 'ModelReference', keys: [{ type: 'AssetAdministrationShell', value: aasId }] },
});

async function removeProperty(smId, idShort) {
  try {
    await api(elementPath(smId, idShort), { method: 'DELETE' });
  } catch (err) {
    if (err.status !== 404) throw err;
  }
}

const nowIso = () => new Date().toISOString().replace(/\.\d+Z$/, 'Z');

// ---------------------------------------------------------------------------------------------
// Ziehung
// ---------------------------------------------------------------------------------------------

const statusOf = (p) => (p.wonAt ? 'won' : p.absentAt ? 'absent' : 'open');

// Gleichverteilte Zufallszahl in [0, n) ohne Modulo-Verzerrung
function randomIndex(n) {
  const limit = Math.floor(0x100000000 / n) * n;
  const buf = new Uint32Array(1);
  do { crypto.getRandomValues(buf); } while (buf[0] >= limit);
  return buf[0] % n;
}

function drawCandidate() {
  const open = state.people.filter((p) => statusOf(p) === 'open');
  if (open.length === 0) return null;
  state.candidate = open[randomIndex(open.length)];
  return state.candidate;
}

const openPrizes = () => state.prizes.filter((z) => !z.winnerAasId);
const prizeByAas = (aasId) => state.prizes.find((z) => z.aasId === aasId);

// prizeAasId leer: Gewinn ohne Preis-AAS
async function confirmCandidate(prizeAasId) {
  const p = state.candidate;
  if (!p) throw new Error(t('errNoCandidate'));
  let prize = null;
  if (prizeAasId) {
    // Frisch laden, falls der Preis in einem anderen Tab schon vergeben wurde
    await loadAll();
    prize = prizeByAas(prizeAasId);
    if (!prize) throw new Error(t('errPrizeGone'));
    if (prize.winnerAasId) throw new Error(t('errPrizeTaken', { name: prizeName(prize.name, prize.rank) }));
  }
  const at = nowIso();
  await setProperty(p.smId, 'WonAt', 'xs:dateTime', at);
  if (prize) {
    await setProperty(p.smId, 'Prize', 'xs:string', prize.name);
    await setShellReference(p.smId, 'PrizeRef', prize.aasId);
    await setShellReference(prize.smId, 'Winner', p.aasId);
    await setProperty(prize.smId, 'AwardedAt', 'xs:dateTime', at);
  }
  state.candidate = null;
  // Nächste Ziehung wieder mit dem Standard (höchster offener Rang)
  document.querySelectorAll('select').forEach((s) => { delete s.dataset.touched; });
  await refresh(true);
}

async function renamePrize(prize, name) {
  await setProperty(prize.smId, 'Name', 'xs:string', name);
  // Beim Gewinner steht der Name mit drin, damit die Teilnehmerliste ohne Nachschlagen auskommt
  const winner = state.people.find((p) => p.aasId === prize.winnerAasId);
  if (winner) await setProperty(winner.smId, 'Prize', 'xs:string', name);
  await refresh(true);
}

async function markCandidateAbsent() {
  const p = state.candidate;
  if (!p) throw new Error(t('errNoCandidate'));
  await setProperty(p.smId, 'AbsentAt', 'xs:dateTime', nowIso());
  state.candidate = null;
  await refresh(true);
}

async function resetPerson(p) {
  // Preis wieder freigeben (Verweis in beide Richtungen)
  for (const prize of state.prizes.filter((z) => z.winnerAasId === p.aasId)) {
    await removeProperty(prize.smId, 'Winner');
    await removeProperty(prize.smId, 'AwardedAt');
  }
  for (const idShort of ['WonAt', 'Prize', 'PrizeRef', 'AbsentAt']) await removeProperty(p.smId, idShort);
  await refresh(true);
}

async function refresh(notify) {
  const keep = state.candidate && state.candidate.smId;
  await loadAll();
  // Ein offener Kandidat bleibt erhalten, solange er noch im Lostopf ist
  state.candidate = keep ? state.people.find((p) => p.smId === keep && statusOf(p) === 'open') || null : null;
  render();
  if (notify && channel) channel.postMessage('changed');
}

// ---------------------------------------------------------------------------------------------
// Darstellung
// ---------------------------------------------------------------------------------------------

const fmtDate = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  return isNaN(d) ? iso : d.toLocaleString(lang === 'de' ? 'de-DE' : 'en-GB', { dateStyle: 'short', timeStyle: 'short' });
};
const fullName = (p) => (p.first + ' ' + p.last).trim();

// Datenschutz: Die Liste zeigt standardmäßig gekürzte Daten. Vollständig erst auf Klick, und
// nach REVEAL_MS wieder gekürzt, damit am Stand niemand versehentlich alles offen stehen lässt.
const REVEAL_MS = 2 * 60 * 1000;
let revealed = false;
let revealTimer = null;

const maskWord = (w) => (w ? w[0] + '•••' : '');
const shortName = (p) => (p.first + ' ' + (p.last ? p.last[0] + '.' : '')).trim();
function maskEmail(email) {
  const [local, domain = ''] = email.split('@');
  const dot = domain.lastIndexOf('.');
  const host = dot > 0 ? domain.slice(0, dot) : domain;
  const tld = dot > 0 ? domain.slice(dot) : '';
  return maskWord(local) + '@' + maskWord(host) + tld;
}
const shownName = (p) => (revealed ? fullName(p) : shortName(p));
const shownEmail = (p) => (revealed ? p.email : maskEmail(p.email));

function setRevealed(on) {
  revealed = on;
  clearTimeout(revealTimer);
  if (on) revealTimer = setTimeout(() => setRevealed(false), REVEAL_MS);
  updateRevealTexts();
  renderAdmin();
}

function updateRevealTexts() {
  const btn = $('toggle-reveal');
  btn.setAttribute('aria-pressed', String(revealed));
  btn.textContent = revealed ? t('mask') : t('reveal');
  $('reveal-hint').textContent = revealed ? t('hintRevealed') : t('hintMasked');
}

function el(tag, attrs, ...children) {
  const node = document.createElement(tag);
  Object.entries(attrs || {}).forEach(([k, v]) => {
    if (k === 'class') node.className = v; else if (k.startsWith('on')) node.addEventListener(k.slice(2), v); else node.setAttribute(k, v);
  });
  children.forEach((c) => node.append(c instanceof Node ? c : document.createTextNode(c ?? '')));
  return node;
}

function showError(err) {
  const box = $('error');
  if (!box) { stageStatus = ''; $('stage-status').textContent = err ? err.message : ''; return; }
  box.hidden = !err;
  box.textContent = err ? err.message : '';
  if (err) console.error(err);
}

// Führt eine Aktion aus, während die Knöpfe gesperrt sind. Ergebnis: true, wenn sie geklappt hat.
async function guarded(fn) {
  if (state.busy) return false;
  state.busy = true;
  setBusy(true);
  try {
    showError(null);
    await fn();
    return true;
  } catch (err) {
    showError(err);
    return false;
  } finally {
    state.busy = false;
    setBusy(false);
  }
}

function setBusy(busy) {
  document.querySelectorAll('button').forEach((b) => { if (busy) b.dataset.wasDisabled = b.disabled; b.disabled = busy || b.dataset.wasDisabled === 'true'; });
  if (!busy) render();
}

function render() {
  if (isStage) renderStage(); else renderAdmin();
}

const prizeLabel = (z) => z.rank + '. ' + prizeName(z.name, z.rank);

// Offene Preise, höchster Rang zuerst (gezogen wird üblicherweise von hinten nach vorn).
// Vorausgewählt ist der höchste offene Rang. Eine bewusst getroffene Auswahl bleibt, solange der
// Preis offen ist (bzw. bei "Ohne Preis").
function fillPrizeSelect(select) {
  const open = openPrizes().slice().sort((a, b) => b.rank - a.rank);
  const current = select.value;
  const options = open.map((z) => el('option', { value: z.aasId }, prizeLabel(z)));
  options.push(el('option', { value: '' }, open.length ? t('noPrize') : t('noPrizeAll')));
  select.replaceChildren(...options);
  const keep = select.dataset.touched && (current === '' || open.some((z) => z.aasId === current));
  select.value = keep ? current : (open[0] ? open[0].aasId : '');
}

function renderPrizes() {
  const list = $('prizes');
  // Nicht neu aufbauen, während jemand einen Namen tippt
  if (list.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return;
  $('no-prizes').hidden = state.prizes.length > 0;
  list.replaceChildren(...state.prizes.map((z) => {
    const input = el('input', { type: 'text', maxlength: '200', value: z.name, 'aria-label': t('prizeNameAria', { n: z.rank }) });
    const save = () => {
      const name = input.value.trim();
      if (name && name !== z.name) guarded(() => renamePrize(z, name));
    };
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); } });
    input.addEventListener('change', save);
    const winner = state.people.find((p) => p.aasId === z.winnerAasId);
    const status = z.winnerAasId
      ? el('span', { class: 'awarded' }, t('awardedTo', { name: winner ? shownName(winner) : t('unknown') }) + (z.awardedAt ? ', ' + fmtDate(z.awardedAt) : ''))
      : el('span', { class: 'muted' }, t('prizeOpen'));
    return el('li', {}, el('span', { class: 'rank' }, z.rank + '.'), input, status);
  }));
}

function renderAdmin() {
  const counts = { open: 0, won: 0, absent: 0 };
  state.people.forEach((p) => { counts[statusOf(p)]++; });
  $('source').textContent = state.infraId == null ? t('loading') : t('source', { name: INFRA_NAME, id: state.infraId });
  $('n-total').textContent = state.people.length;
  $('n-open').textContent = counts.open;
  $('n-won').textContent = counts.won;
  $('n-absent').textContent = counts.absent;
  $('draw').disabled = state.busy || counts.open === 0;
  fillPrizeSelect($('prize'));
  renderPrizes();

  const c = state.candidate;
  $('candidate').hidden = !c;
  if (c) {
    $('cand-name').textContent = fullName(c);
    $('cand-detail').textContent = [c.company, shownEmail(c)].filter(Boolean).join(' · ');
  }

  const filter = $('filter').value.trim().toLowerCase();
  // Gesucht wird nur in dem, was gerade sichtbar ist
  const rows = state.people.filter((p) => !filter || [shownName(p), p.company, shownEmail(p)].join(' ').toLowerCase().includes(filter));
  const labels = statusLabels();
  $('rows').replaceChildren(...rows.map((p) => {
    const s = statusOf(p);
    const badge = el('span', { class: 'badge ' + s }, labels[s]);
    const info = s === 'won' ? [p.prize && prizeName(p.prize), fmtDate(p.wonAt)].filter(Boolean).join(', ') : s === 'absent' ? fmtDate(p.absentAt) : '';
    const reset = s === 'open' ? '' : el('button', {
      type: 'button', class: 'link', title: t('resetTitle'),
      onclick: () => guarded(() => resetPerson(p)),
    }, t('reset'));
    return el('tr', {},
      el('td', {}, shownName(p)), el('td', {}, p.company), el('td', {}, shownEmail(p)),
      el('td', { class: 'when' }, fmtDate(p.registeredAt)),
      el('td', {}, badge, info ? el('div', { class: 'muted' }, info) : ''),
      el('td', {}, reset));
  }));
  $('empty').hidden = state.people.length > 0;
}

const statusLabels = () => ({ open: t('open'), won: t('won'), absent: t('absentStatus') });

function exportCsv() {
  const cols = t('csvCols');
  const labels = statusLabels();
  // Führende =, +, -, @ entschärfen, damit Excel nichts als Formel ausführt
  const cell = (v) => {
    let s = String(v ?? '');
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  };
  const lines = [cols.map(cell).join(';')].concat(state.people.map((p) => [
    p.first, p.last, p.company, p.email, p.registeredAt, labels[statusOf(p)], p.wonAt, p.prize, p.absentAt,
  ].map(cell).join(';')));
  const blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
  const a = el('a', { href: URL.createObjectURL(blob), download: t('csvFile') + '-' + new Date().toISOString().slice(0, 10) + '.csv' });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// --- Großanzeige -------------------------------------------------------------------------------

let spinning = false;
let stageStatus = '';  // Textschlüssel
let stageAwarded = null;  // nach einer Vergabe: { name, rank } bzw. {} ohne Preis

function setStageStatus(key) {
  stageStatus = key;
  $('stage-status').textContent = key ? t(key) : '';
}

function renderStage() {
  const open = state.people.filter((p) => statusOf(p) === 'open').length;
  $('stage-count').textContent = t('inPot', { n: open });
  $('stage-draw').disabled = state.busy || spinning || open === 0;
  $('stage-confirm').disabled = state.busy || spinning || !state.candidate;
  $('stage-absent').disabled = state.busy || spinning || !state.candidate;
  const select = $('stage-prize-select');
  fillPrizeSelect(select);
  const prize = prizeByAas(select.value);
  // Nach einer Vergabe bleibt deren Preis stehen, bis neu gezogen wird
  const shown = stageAwarded || prize;
  $('stage-prize').textContent = shown && shown.rank ? prizeName(shown.name, shown.rank) : '';
  if (stageStatus) $('stage-status').textContent = t(stageStatus);
}

// Auf der Großanzeige nur Vorname und Firma, keine E-Mail
function showOnStage(p, cls) {
  const name = $('stage-name');
  name.className = 'stage-name ' + (cls || '');
  name.textContent = p ? p.first : '';
  $('stage-company').textContent = p ? p.company : '';
}

function stageDraw() {
  if (spinning || state.busy) return;
  const open = state.people.filter((p) => statusOf(p) === 'open');
  if (open.length === 0) { setStageStatus('errPotEmpty'); return; }
  const winner = drawCandidate();
  spinning = true;
  stageAwarded = null;
  setStageStatus('');
  renderStage();
  // Namen rotieren, immer langsamer, dann steht der gezogene Name
  const steps = 28;
  let i = 0;
  const tick = () => {
    if (i < steps) {
      showOnStage(open[randomIndex(open.length)], 'spinning');
      i++;
      setTimeout(tick, 40 + Math.pow(i / steps, 3) * 360);
    } else {
      showOnStage(winner, 'final');
      spinning = false;
      setStageStatus('stagePrompt');
      renderStage();
    }
  };
  tick();
}

function stageConfirm() {
  if (!state.candidate || spinning) return;
  const p = state.candidate;
  guarded(async () => {
    const prize = prizeByAas($('stage-prize-select').value);
    await confirmCandidate(prize ? prize.aasId : '');
    showOnStage(p, 'final');
    stageAwarded = prize ? { name: prize.name, rank: prize.rank } : {};
    setStageStatus('congrats');
  });
}

function stageAbsent() {
  if (!state.candidate || spinning) return;
  guarded(async () => {
    await markCandidateAbsent();
    showOnStage(null);
    setStageStatus('redraw');
  }).then((ok) => { if (ok) setTimeout(stageDraw, 900); });
}

function toggleFullscreen() {
  if (document.fullscreenElement) document.exitFullscreen();
  else document.documentElement.requestFullscreen().catch(() => {});
}

// ---------------------------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------------------------

const isStage = params.get('view') === 'stage';

function initAdmin() {
  $('admin').hidden = false;
  $('reload').addEventListener('click', () => guarded(() => refresh(false)));
  $('csv').addEventListener('click', exportCsv);
  $('filter').addEventListener('input', renderAdmin);
  $('toggle-list').addEventListener('click', () => {
    const open = $('list').hidden;
    $('list').hidden = !open;
    $('toggle-list').setAttribute('aria-expanded', String(open));
    // Beim Zuklappen immer wieder kürzen
    if (!open && revealed) setRevealed(false);
  });
  $('toggle-reveal').addEventListener('click', () => setRevealed(!revealed));
  $('open-stage').addEventListener('click', () => {
    const url = new URL(location.href);
    url.searchParams.set('view', 'stage');
    url.searchParams.set('lang', lang);
    window.open(url.toString(), 'raffle-stage');
  });
  $('draw').addEventListener('click', () => {
    if (!drawCandidate()) showError(new Error(t('errPotEmpty')));
    renderAdmin();
  });
  $('prize').addEventListener('change', () => { $('prize').dataset.touched = '1'; });
  $('confirm').addEventListener('click', () => guarded(() => confirmCandidate($('prize').value)));
  $('absent').addEventListener('click', () => guarded(async () => {
    await markCandidateAbsent();
    drawCandidate();
  }));
  $('discard').addEventListener('click', () => { state.candidate = null; renderAdmin(); });
}

function initStage() {
  $('stage').hidden = false;
  $('stage-draw').addEventListener('click', stageDraw);
  $('stage-confirm').addEventListener('click', stageConfirm);
  $('stage-absent').addEventListener('click', stageAbsent);
  $('stage-full').addEventListener('click', toggleFullscreen);
  $('stage-prize-select').addEventListener('change', () => { $('stage-prize-select').dataset.touched = '1'; renderStage(); });
  document.addEventListener('keydown', (e) => {
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) return;
    if (e.key === ' ') { e.preventDefault(); stageDraw(); }
    else if (e.key === 'Enter') { e.preventDefault(); stageConfirm(); }
    else if (e.key === 'n' || e.key === 'N') stageAbsent();
    else if (e.key === 'f' || e.key === 'F') toggleFullscreen();
    else if (e.key === 'l' || e.key === 'L') setLang(lang === 'de' ? 'en' : 'de');
  });
}

if (isStage) initStage(); else initAdmin();
document.querySelectorAll('[data-lang]').forEach((b) => b.addEventListener('click', () => setLang(b.dataset.lang)));
// Umschalten in einem anderen Tab (Verwaltung bzw. Großanzeige) übernehmen
window.addEventListener('storage', (e) => { if (e.key === LANG_KEY && e.newValue && e.newValue !== lang) setLang(e.newValue, false); });
applyLang();
if (channel) channel.onmessage = () => { if (!state.busy && !spinning) guarded(() => refresh(false)); };
guarded(() => refresh(false));
